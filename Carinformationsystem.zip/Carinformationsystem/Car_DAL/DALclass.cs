﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using CAREntityLayer;
using CARException;
using System.IO;

namespace Car_DAL
{
    public class DALclass
    {
        public static List<CarEntities> Carlist = new List<CarEntities>();

        public static string FileName = @"ListofCars.txt";

        public static bool AddCarDal(CarEntities newcar)
        {
            bool CarAdded = false;
            try
            {


                Carlist.Add(newcar);
                CarAdded = true;
                SetSerialization();


            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public static CarEntities SearchCarDAL(string model)
        {

            CarEntities searchcar = null;
            try
            {
                for (int i = 0; i < Carlist.Count; i++)
                {
                    CarEntities car = Carlist[i];
                    if (car.Model == model)
                    {
                        searchcar = Carlist[i];
                        break;
                    }
                }

            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            return searchcar;
        }

        public  static bool ModifyCarDAL(CarEntities modifycar)
        {
            bool Modified = false;
            try
            {



                for (int i = 0; i < Carlist.Count; i++)
                {
                    if (Carlist[i].Model == modifycar.Model)
                    {
                        Carlist[i].ManufacturerName = modifycar.ManufacturerName;
                        Carlist[i].Mileage = modifycar.Mileage;
                        Carlist[i].price = modifycar.price;
                        Carlist[i].Seats = modifycar.Seats;
                        Carlist[i].BootSpace = modifycar.BootSpace;
                        Carlist[i].Airbags = modifycar.Airbags;
                        Carlist[i].BHP = modifycar.BHP;
                        Carlist[i].Engine = modifycar.Engine;

                        SetSerialization();
                        break;
                    }
                }
                Modified = true;


            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            return Modified;
        }

        public static bool RemoveCarDAL(string modelremove)
        {

            bool removed = false;
            try
            {
                for (int i = 0; i < Carlist.Count; i++)
                {
                    CarEntities car = Carlist[i];
                    if (car.Model == modelremove)
                    {
                        Carlist.RemoveAt(i);
                        removed = true;
                        SetSerialization();
                        break;
                    }
                }


            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            return removed;
        }

        public static List<CarEntities> ShowDAL()
        {
            try
            {
                DeserializeFile();
                return Carlist;
            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
        }

        

        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(FileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, Carlist);
                    file.Close();
                }
            }
            catch (FileNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void SetList()
        {
            DeserializeFile();
        }

       
        public static void DeserializeFile()
        {
            try
            {

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + FileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    Carlist = bf.Deserialize(file) as List<CarEntities>;
                    file.Close();


                }
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}

