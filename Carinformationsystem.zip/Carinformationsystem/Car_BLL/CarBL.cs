﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CARException;
using Car_DAL;
using CAREntityLayer;
using System.Text.RegularExpressions;
using System.IO;
namespace Car_BLL
{
    public class CarBL
    {
        

        public static bool Validate(CarEntities car)
        {
            bool validate = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (!(Regex.IsMatch(car.ManufacturerName, @"^[A-Z]{1}[a-z]{2,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Manufacturer name should contain only alphabets and First letter should be in Caps");

                }
                List<CarEntities> Carlist = new List<CarEntities>();
                for (int i = 0; i < Carlist.Count; i++)
                {
                    for (int j = i + 1; j < Carlist.Count; j++)
                    {
                        if (Carlist[i].Model == Carlist[j].Model)
                        {
                            validate = false;
                            sb.Append(Environment.NewLine + "Model should be unique");
                        }
                    }
                }
                if (car.Type != "Hatchback" && car.Type != "SUV" && car.Type != "Sedan")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Type name should be Hatchback or Sedan or SUV");
                }
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "BHP should be a number");
                }
                if (car.Transmission != "Manual" && car.Transmission != "Automatic")
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seats.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "seats should be a number");
                }
                if (!(Regex.IsMatch(car.Airbags, @"^[A-Za-z]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    sb.Append(Environment.NewLine + "Price should be a number");
                }

                if (car.ManufacturerName == String.Empty || car.Mileage.ToString() == String.Empty || car.Model == String.Empty || car.Seats.ToString() == String.Empty || car.price.ToString() == String.Empty || car.Transmission == String.Empty || car.Type == String.Empty || car.BootSpace.ToString() == String.Empty || car.Airbags == String.Empty)
                {
                    validate = false;
                    sb.AppendLine("All Fields are  mandatory");
                }
                if (validate == false)

                    throw new CARException.Myexception(sb.ToString());
            }
            catch (Myexception ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }


        public static bool AddBLL(CarEntities car)
        {
            bool added = false;
            try
            {
                if (Validate(car))
                {


                    added = DALclass.AddCarDal(car);

                }
            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool ModifyBLL(CarEntities car)
        {
            bool modified = false;
            try
            {
                if (Validate(car))
                {

                    modified = DALclass.ModifyCarDAL(car);

                }
            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return modified;
        }

        public static CarEntities SearchBLL(string model)
        {
            CarEntities searchcar = null;
            try
            {
                searchcar = DALclass.SearchCarDAL(model);

            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchcar;
        }

        public static bool RemoveBLL(string model)
        {
            bool removed = false;
            try
            {
                if (model != string.Empty)
                {
                    removed = DALclass.RemoveCarDAL(model);
                }
                else
                {
                    throw new CARException.Myexception("Invalid Customer ID");
                }


            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return removed;
        }

        public static List<CarEntities> ShowBLL()
        {
            List<CarEntities> CarList = null;
            try
            {


                CarList = DALclass.ShowDAL();


            }
            catch (CARException.Myexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarList;
        }

        public static void SetSerialization()
        {
            try
            {
                if (Car_DAL.DALclass.Carlist != null)
                {
                    Car_DAL.DALclass.SetSerialization();
                }
            }
            catch (CARException.Myexception e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void setlist()
        {
            try
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + Car_DAL.DALclass.FileName))
                    Car_DAL.DALclass.SetList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
